 @if ($project->duration !== 1)
            <div class="div-title">
                {{ __('Salaries Plan') }}
            </div>


            <div class="formItem ">
                <div class="row ml-1 mr-1">
                    <div class="col-3">
                        <div class="form-group">
                            <label>{{ __('Salaries Annual Increase %') }}</label>
                            <input type="number" step="any" class="form-control growth_percentage_in_diff_parent only-greater-than-or-equal-zero-allowed" name="salaries_annual_increase" value="{{ $project->getSalaryIncreaseRate() }}" id="salaries_annual_increase">
                        </div>



                    </div>
                    <div class="col-3">
                        <div class="form-group">
                            <label>{{ __('Salaries Tax Rate %') }}</label>
                            <input type="number" step="any" class="form-control only-greater-than-or-equal-zero-allowed" name="salaries_tax_rate" value="{{ $project->getSalaryTaxRate() }}">
                        </div>

                    </div>
                    <div class="col-md-3">
                        <div class="form-group">
                            <label>{{ __('Social Insurance Rate %') }}</label>
                            <input type="number" step="any" class="form-control only-greater-than-or-equal-zero-allowed" name="social_insurance_rate" value="{{ $project->getSocialInsuranceRate() }}">
                        </div>
                    </div>
                </div>



            </div>

            @endif
            @php
            $index = 0 ;
            @endphp
            {{-- Salaries Expenses --}}
            @foreach ( getManpowerTypes() as $id => $manpowerOptionArr)
            <div class="div-title">
                {{$manpowerOptionArr['title']}}
            </div>

            <div class="formItem repeater{{ $id }}">

                <div data-repeater-list="{{ $id }}">
                    @foreach(count($manpowers->where('type',$id)) ? $manpowers->where('type',$id) : [null] as $currentRowIndex=>$currentManpower)
                    <div data-repeater-item class="container parent-for-salary-amount">
                        <input type="hidden" name="id" value="{{ $currentManpower ? $currentManpower->id : 0 }}">
                        <div class="row closest-parent pb-2  col-12">
                            <div class="col-3">
                                <label>{{ __('Position') }}</label>
                                <input type="text" name="position" class="form-control" value="{{ $currentManpower ? $currentManpower->getPositionName() : '' }}">
                            </div>

                            <div class="col-2">
                                <label>{{ __('Avg. Salary') }}</label>
                                <input type="text" name="avg_salary" class="form-control number_growth_amount_in_diff_parent only-greater-than-or-equal-zero-allowed" value="{{ $currentManpower ? $currentManpower->getAvgSalary() : 0 }}">
                            </div>

                            <div class="col-2">
                                <label>{{ __('Existing Count') }}</label>
                                <input @if($project->isNewCompany()) readonly @endif type="text" name="existing_count" class="form-control only-greater-than-or-equal-zero-allowed" value="{{ $currentManpower ? $currentManpower->getExistingCount() : 0 }}">
                            </div>

                            <div class="col-3 common-parent">
                                <label class="visible-hidden">{{ __('Hirings') }}</label>
                                <div>
                                    <button class="btn btn-primary btn-md text-nowrap " type="button" data-toggle="modal" data-target="#modal-{{ $id }}-{{ $currentRowIndex }}">{{ __('New Hirings') }}</button>
                                    <input data-repeater-delete type="button" class="btn btn-danger btn-md ml-2" value="{{ __('Delete') }}">
                                </div>
                            </div>
                        </div>

                        <!-- Modal for New Hirings -->
                        <div class="modal fade" id="modal-{{ $id }}-{{ $currentRowIndex }}" tabindex="-1" role="dialog" aria-labelledby="modalLabel-{{ $id }}-{{ $currentRowIndex }}" aria-hidden="true">
                            <div class="modal-dialog modal-full" role="document">
                                <div class="modal-content">
                                    <div class="modal-header header-border">
                                        <h5 class="modal-title font-size-1rem text-blue" id="modalLabel-{{ $id }}">
										@if($currentManpower)
										{{ __('New Hiring For') }}  
										
										{{ $currentManpower ? $currentManpower->getPositionName() : '' }}
										@else 
									{{ __('New Hiring') }}  		
@endif										
										 </h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <table>
                                            <tbody>
                                                @php
                                                $startIndex = 1 ;
                                                $yearIndexWithItsMonthsAsIndexAndString = $project->getYearIndexWithItsMonthsAsIndexAndString();
                                                @endphp
                                                @foreach($yearIndexWithItsMonthsAsIndexAndString as $yearIndex => $itsMonths)
                                                <tr>
                                                    @foreach($itsMonths as $dateAsIndex => $dateAsString )
                                                    @php $dateFormatted=\Carbon\Carbon::make($dateAsString)->format('M`Y');
                                                    @endphp
                                                    <td>
                                                        <div class="form-group text-center">
                                                            <label>{{ $dateFormatted }}</label>
                                                            <div class="ml-2">
                                                                <input class="form-control input-border" data-main-category="{{ $id }}" data-sub-category="hirings" data-last-index="{{ $dateAsIndex }}" name="[hirings]" multiple value="{{ $currentManpower ? $currentManpower->getHiringAtDate($dateAsIndex):0 }}">
                                                            </div>
                                                        </div>
                                                    </td>
                                                    @endforeach
                                                </tr>
                                                @endforeach
                                            </tbody>
                                        </table>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-primary save-modal" data-dismiss="modal">{{ __('Save') }}</button>
                                        {{-- <button type="button" class="btn btn-primary">{{ __('Save changes') }}</button> --}}
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    @endforeach
                </div>
                <div class="ml-5 mt-4 d-flex justify-content-between" style="width:94%">
                    <input data-repeater-create type="button" class="btn btn-success btn-sm " value="{{ __('Add Position') }}">
                    @if($manpowerOptionArr['has_allocation'])
                    <button class="btn bg-green btn-md text-nowrap " type="button" data-toggle="modal" data-target="#modal-allocate-{{ $id }}">{{ __('Allocate On Products') }}</button>
                    <div class="modal fade" id="modal-allocate-{{ $id }}" tabindex="-1" role="dialog" aria-labelledby="modalLabel-{{ $id }}" aria-hidden="true">
                        <div class="modal-dialog modal-md modal-dialog-centered" role="document">
                            <div class="modal-content">
                                <div class="modal-header header-border">
                                    <h5 class="modal-title font-size-1rem" id="modalLabel-{{ $id }}">{{ __('Allocate') }}</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <table class="table w-full closest-parent">
                                        <tbody>
										
										   <tr class="closest-parent">
                            <td>

                                <div class="d-flex  align-content-center">
                                    <span class="mr-3">
                                        <b>{{ __('Allocate based on Revenues Percentages') }}</b>
                                    </span>
                                    <div class="kt-radio-inline mt--5">

                                        <label class="kt-radio kt-radio--success text-black font-size-18px">
                                            @php
                                      	    $isAsRevenuePercentage = $project ? $project->getManpowerIsAsRevenuePercentage($id) : 1 ;
                                            @endphp
                                            <input type="checkbox" class="allocate-checkbox" value="1" name="manpower_is_as_revenue_percentages[{{ $id }}]" @if( $isAsRevenuePercentage) checked @endisset>
                                            <span></span>
                                        </label>

                                    </div>
                                </div>

                            </td>


                        </tr>
						
                                            @php
                                            $allocations = $project->getManpowerAllocationForType($id) ;
                                            @endphp
                                            @foreach($products as $product)
                                            @php
                                            $percentage = $allocations[$product->id]??(100/count($products));
                                            @endphp
											
											
                                            <tr>

                                                <td>
                                                    <div class="form-group d-flex  dep-parent text-center">

                                                        <div class="col-9 text-left">
                                                            <label>{{ __('Product') }}</label>
                                                            <input readonly class="form-control" name="manpower_allocations[{{ $id }}][products][{{ $product->id }}]" type="text" value="{{ $product->getName() }}">
                                                            <input multiple class="form-control " name="product_id" type="hidden" value="{{ $product->id }}">


                                                        </div>
                                                        <div class="col-3 text-left">
                                                            <label>{{ __('Perc.%') }}</label>
                                                            <input class="form-control percentage-allocation total_input input-border" name="manpower_allocations[{{ $id }}][percentages][{{ $product->id }}]" data-old-value="{{ $percentage }}"  value="{{ $percentage }}">
                                                        </div>


                                                    </div>
                                                </td>

                                            </tr>
                                            @endforeach

                                            <tr>

                                                <td>
                                                    <div class="form-group d-flex   text-center">

                                                        <div class="col-9 text-left">
                                                            <label>{{ __('Total') }}</label>
                                                            <input readonly class="form-control" type="text" value="{{ __('Total') }}">
                                                        </div>
                                                        <div class="col-3	 text-left">
                                                            <label>{{ __('Total %') }}</label>
                                                            <input readonly class="form-control must-not-exceed-100 total_row_result input-border" value="{{ 0 }}">
                                                        </div>


                                                    </div>
                                                </td>

                                            </tr>


                                        </tbody>
                                    </table>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn  save-modal btn-primary" data-dismiss="modal">{{ __('Save') }}</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    @endif
                </div>
            </div>

            @endforeach
